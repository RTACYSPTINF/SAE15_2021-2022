"""
On crée une fonction nommée :
        extraction_ville_csv(fichier)
Travail à faire
Classement national de la ville en fonction du nombre d’habitants :
        def classement_national_ville_habitants(fich):

Classement national de la ville en fonction de la superficie de la ville :
        def classement_national_ville_superficie(fich):

Classement national de la ville en fonction de la densité de population :
        def classement_national_ville_densite(fich):

Classement département de la ville en fonction du nombre d’habitants :
        def classement_departemental_ville_habitant(fich):

Classement département de la ville en fonction de la superficie de la ville :
        def classement_departemental_ville_superficie(fich):

Classement département de la ville en fonction de la densité de population
        def classement_departemental_ville_densité(fich)
"""
import ressources
from pathlib import *
import os
from math import cos, sin, asin, acos, pi






def recup_ville_de_france(fichier):
    """
    Cette fonction permet d'extraire les données du fichier villes_france.csv
    le fait d'utiliser readlines permet de récupérer une liste dont chaque élément coorespond à une ville ainsi que toutes les données associées
    :param fichier: fichier "villes_france.csv"
    :return: une liste "recup" dont chaque élément est une str qui comporte toutes les données d'une ville (27 données par ville au total)
    """
    # on se place dans le bon répertoire
    p = Path('E:/SAE15/SAE15_2021-2022')
    os.chdir(p)
    with open(fichier,'r') as fich:
        recup = fich.readlines()
    return recup



def conversionDMS_DEGRE(deg, min, sec):
    """

    :param deg:
    :param min:
    :param sec:
    :return:
    """
    angle_degre = 0
    angle_degre = deg + min /60 + sec/60/60
    return angle_degre

def calcul_distance(phiA, lambdaA, phiB, LambdaB):
    """

    :param phiA:
    :param lambdaA:
    :param phiB:
    :param LambdaB:
    :return:
    """
    pass
"""
print(conversionDMS_DEGRE(1,50,3.156468))

A = ((45,0,0), (0, 0, 0))
B = ((46, 15, 28.463641), (1, 50, 03.156468))

Long_angleA= conversionDMS_DEGRE(A[0][0], A[0][1], A[0][2])
Long_angleB= conversionDMS_DEGRE(B[0][0], B[0][1], B[0][2])

Lat_angleA= conversionDMS_DEGRE(A[1][0], A[1][1], A[1][2])
Lat_angleB= conversionDMS_DEGRE(B[1][0], B[1][1], B[1][2])
"""
def calcul_distance(VilleA, villeB):


    """

    :param VilleA: tuple (latA, longA)
    :param villeB: tuple (latB, longB)
    :return: distance en km
    """
    # conversion en radin
    lambdaA = villeA[1]*pi/180
    lambdaB = villeB[1]*pi/180
    phiA = villeA[0]*pi/180
    phiB = villeB[0]*pi/180
    print(lambdaA, phiA , lambdaB, phiB)

    distance = acos(sin(phiA)*sin(phiB) + cos(phiA)*cos(phiB)*(lambdaB - lambdaA))
    return distance

"""
villeA =  Long_angleA, Lat_angleA
villeB = Long_angleB, Lat_angleB

distance = calcul_distance(villeA, villeB)

print(distance)
"""

def extraction_ville_gps(villes_liste):
    """
    Cette fonction va renvoyer une liste de liste avec les données du fichier initial au bon format.
    par exemple, avant traitement avec cette fonction, toutes les données sont du type str.

    int(eval(i[1])),            departement
    eval(i[3]),                 ville
    i[14],                      pop en 2010
    i[15],                      pop en 1999
    i[16],                      pop en 2012
    i[17],                      surface
    float(eval(i[19])),         latitude
    float(eval(i[20])),         longitude
    i[25],                      alt min
    i[26]])                     alt max

    :param villes_liste:
    :return:
    """
    L= []
    temp = []
    for i in villes_liste:
        temp.append(i.split(','))
    for i in temp:
        if ((eval(i[1]) != '2A') and (eval(i[1]) != '2B'))  and i[25] != 'NULL':
            L.append([int(eval(i[1])),
                      eval(i[3]),
                      int(eval(i[14])),
                      int(eval(i[15])),
                      int(eval(i[16])),
                      float(eval(i[18])),
                      float(eval(i[19])),
                      float(eval(i[20])),
                      i[25],
                      i[26]])
        else:
            L.append([eval(i[1]),
                      eval(i[3]),
                      int(eval(i[14])),
                      int(eval(i[15])),
                      int(eval(i[16])),
                      float(eval(i[18])),
                      float(eval(i[19])),
                      float(eval(i[20])),
                      i[25],
                      i[26]])

    return L




villes_liste = recup_ville_de_france('villes_france.csv')
aa = extraction_ville_gps(villes_liste)

def compte_villes_par_dep(fich):
    """
    renvoie un dictionnaire avec comme clé le département et comme valeurs le nombre de villes par département
    :param fich: est  une liste
            [[1, 'CORMORANCHE-SUR-SAONE', 4.83333, 46.2333],
            [1, 'PLAGNE', 5.73333, 46.1833],
            [1, 'TOSSIAT', 5.31667, 46.1333]]
    cette liste a été obtenue par la fonction "extraction villes GPS
    :return:
    """
    d={}
    cpt = 0
    for i in range(95):
        cpt = 0
        for j in fich:
            if j[0] == i:
                cpt += 1
                d[i] = cpt
    return d

def Nb_habitants_villes_par_dep2012(fich, departement):
    """
    renvoie un dictionnaire contenant comme clé : le nom de ville
    comme valeur : le nombre d'habitant en 2012 [
    :param fich:
    :param departement:
    :return: un dictionnaire (pour le departement 74
{'ANDILLY': 800,
 'MINZIER': 800,
 'SAINT-PAUL-EN-CHABLAIS': 2100, ...}
    """
    d = {}
    for i in fich:
        if i[0] == departement:
            d[i[1]]=i[4]
    return d

def Nb_habitants_villes_par_dep1999(fich, departement):
    """
    renvoie un dictionnaire contenant comme clé : le nom de ville
    comme valeur : le nombre d'habitant en 1999 [
    :param fich:
    :param departement:
    :return: un dictionnaire (pour le departement 74
{'ANDILLY': 800,
 'MINZIER': 800,
 'SAINT-PAUL-EN-CHABLAIS': 2100, ...}
    """
    d = {}
    for i in fich:
        if i[0] == departement:
            d[i[1]]=i[2]
    return d

def Nb_habitants_villes_par_dep2010(fich, departement):
    """
    renvoie un dictionnaire contenant comme clé : le nom de ville
    comme valeur : le nombre d'habitant en 2010 [
    :param fich:
    :param departement:
    :return: un dictionnaire (pour le departement 74
{'ANDILLY': 800,
 'MINZIER': 800,
 'SAINT-PAUL-EN-CHABLAIS': 2100, ...}
    """
    d = {}
    for i in fich:
        if i[0] == departement:
            d[i[1]]=i[3]
    return d

def Nb_habitants_villes_global(fich):
    """
    renvoie un dictionnaire pour l'ensemble du fichier contenant comme clé : le nom de ville
    comme valeur : le nombre d'habitant en 1999 [
    :param fich:
    :return: un dictionnaire (pour le departement 74
{'ANDILLY': 800,
 'MINZIER': 800,
 'SAINT-PAUL-EN-CHABLAIS': 2100, ...}
    """
    d = {}
    for i in fich:
        d[i[1]]=i[4]
    return d

def plus_grande_ville_N(N):
    """

    :param N:
    :return:
    """
    dico_ville = Nb_habitants_villes_global(extraction_ville_gps(villes_liste))

    # Inversion du dictionnaire
    dico_ville_inverse = {}
    for k,v in dico_ville.items():
        dico_ville_inverse[v]=k
    liste_tri = sorted(dico_ville_inverse)
    # on recupere le N valeurs les plus petites
    petitesN = liste_tri[:N]
    grandesN = liste_tri[len(liste_tri) - N :]
    liste_petiteN = []
    for i in petitesN:
        liste_petiteN.append((dico_ville_inverse[i], i))
    liste_grandeN = []
    for i in grandesN:
        liste_grandeN.append((dico_ville_inverse[i], i))
    return liste_petiteN, liste_grandeN

if __name__ == "__main__":
    dep2012 = Nb_habitants_villes_par_dep2012(aa, 73)
    dep1999 = Nb_habitants_villes_par_dep1999(aa, 73)
    dep2010 = Nb_habitants_villes_par_dep2010(aa, 73)

    L = []
    for i in range(65,76):
        L.append(Nb_habitants_villes_par_dep2012(aa,i))

    # recherche de la ville la plus peuplée

