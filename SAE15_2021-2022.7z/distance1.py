https://www.it-swarm-fr.com/fr/python/obtenir-la-distance-entre-deux-points-en-fonction-de-la-latitude-longitude/1041560830/

import mpu
d : int
# Point one
lat1 = 52.2296756
lon1 = 21.0122287

# Point two
lat2 = 52.406374
lon2 = 16.9251681

# What you were looking for
dist = mpu.haversine_distance((lat1, lon1), (lat2, lon2))
print(dist)  # gives 278.45817507541943.
